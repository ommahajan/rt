package com.sp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sp.constants.ErrorConst;
import com.sp.dto.StudentDTO;
import com.sp.exception.InvalidApiKeyException;
import com.sp.exception.InvalidAppKeyException;
import com.sp.service.SpService;

@RestController
@RequestMapping("/spa")
public class SpController {
	
    @Autowired
    SpService spService;
	
//    @GetMapping(value = "/get-student-list-by-department")
//	public ResponseEntity<Object> getStudentListByDepartment(HttpServletRequest request,
//			@RequestHeader("appKey") String appKey, @RequestParam("apiKey") String apiKey,
//			@RequestParam("dept") String dept) {
//		if (apiKey == null) {
//			throw new InvalidApiKeyException(ErrorConst.API_KEY_IS_REQUIRED,
//					"Api Key is required for accessing this Resource");
//		}
//
//		if (apiKey != null && apiKey.equals("XYZ")) {
//			if (appKey != null && !appKey.isEmpty() && "ABC".equals(appKey)) {
//				return new ResponseEntity<>(
//						spService.getStudentListByDepartment(dept),
//						HttpStatus.OK);
//
//			} else {
//				throw new InvalidAppKeyException(ErrorConst.INVALID_APP_KEY, "Invalid APP Key");
//			}
//		} else {
//			throw new InvalidApiKeyException(ErrorConst.INVALID_API_KEY, "Invalid API Key");
//		}
//
//	}
    
    @GetMapping(value = "/get-student-list-by-department")
   	public ResponseEntity<Object> getStudentListByDepartment(@RequestParam("dept") String dept) {

   				return new ResponseEntity<>(
   						spService.getStudentListByDepartment(dept),
   						HttpStatus.OK);

   	}
    
	@PostMapping(value = "/get-student-list-by-ids")
	public ResponseEntity<Object> getStudentDetails(@RequestBody List<Map<String, Object>> studIdList) {

		Map<String, Object> responseMap = new HashMap<>();
		List<StudentDTO> studList = new ArrayList<>();

		for (Map<String, Object> studId : studIdList) {

			StudentDTO student = new StudentDTO();
			
			Integer sId = (Integer) studId.get("studId");

			if (sId == 1) {
				student.setId(101);
				student.setName("Om Mahajana");
				student.setDept("CSE");
				studList.add(student);
			}
			if (sId == 2) {
				student.setId(102);
				student.setName("Ravi");
				student.setDept("IT");
				studList.add(student);
			}
			if (sId == 3) {
				student.setId(103);
				student.setName("Avi");
				student.setDept("CT");
				studList.add(student);
			}

		}

		responseMap.put("studentList", studList);
		responseMap.put("message", "Student list Delivered Successfully..!!");
		responseMap.put("errorCode", null);
		responseMap.put("status", true);
		
		return new ResponseEntity<>(responseMap, HttpStatus.OK);

	}
	
	@GetMapping(value = "/get-student-list-by-req-param-as-ids")
	public ResponseEntity<Object> getStudentListByReqParamIds(@RequestParam String studIds) {

		Map<String, Object> responseMap = new HashMap<>();
		List<StudentDTO> studList = new ArrayList<>();
		
		String[] splitedstudIds = studIds.split(",");

		for (String studId : splitedstudIds) {

			StudentDTO student = new StudentDTO();
			
			Integer sId = Integer.parseInt(studId);

			if (sId == 1) {
				student.setId(101);
				student.setName("Om Mahajana");
				student.setDept("CSE");
				studList.add(student);
			}
			if (sId == 2) {
				student.setId(102);
				student.setName("Ravi");
				student.setDept("IT");
				studList.add(student);
			}
			if (sId == 3) {
				student.setId(103);
				student.setName("Avi");
				student.setDept("CT");
				studList.add(student);
			}

		}

		responseMap.put("studentList", studList);
		responseMap.put("message", "Student list Delivered Successfully..!!");
		responseMap.put("errorCode", null);
		responseMap.put("status", true);
		
		return new ResponseEntity<>(responseMap, HttpStatus.OK);

	}
	
	@GetMapping(value = "/say-hello")
	public ResponseEntity<Object> sayHello(@RequestParam String str) {

		return new ResponseEntity<>("Hello " + str, HttpStatus.OK);

	}
	
	@PostMapping(value = "/say-hello-with-api-key-and-response-as-map-object")
	public ResponseEntity<Map<String, Object>> sayHelloWithApiKeyAndResponseAsMapObj(@RequestHeader("apiKey") String apiKey, @RequestBody String strObject) {
		
		Map<String, Object> resp = new HashMap<>();
		
		if(strObject != null) {
			resp.put("status", "success");
		}
		
		return new ResponseEntity<>(resp, HttpStatus.OK);

	}
	
	@PostMapping(value = "/say-hello-with-api-key-and-response-as-string-object")
	public ResponseEntity<String> sayHelloWithApiKeyAndResponseAsStringObj(@RequestHeader("apiKey") String apiKey, @RequestBody String strObject) {
		
		String resp = "failed";
		
		if(strObject != null) {
			resp = "success";
		}
		
		return new ResponseEntity<>(resp, HttpStatus.OK);

	}
	
	@PostMapping(value = "/get-course-list-by-student-details")
	public ResponseEntity<?> getCourseListByStudentDetails(@RequestBody Object studDetls) {
		
		Map<String,Object> resp = new LinkedHashMap<>();
		
		List<Map<String,Object>> courseListMap = new ArrayList<>();
		
		Map<String,Object> course1 = new LinkedHashMap<>();
		Map<String,Object> course2 = new LinkedHashMap<>();
		Map<String,Object> course3 = new LinkedHashMap<>();
		Map<String,Object> course4 = new LinkedHashMap<>();
		
		if(studDetls instanceof List<?>) {
		
		@SuppressWarnings("unchecked")
		List<Object> studDetlsList = (List<Object>) studDetls;
		
		if(studDetlsList.get(0) instanceof LinkedHashMap<?, ?>) {
			
			@SuppressWarnings("unchecked")
			LinkedHashMap<String, Object> lhm = (LinkedHashMap<String, Object>) studDetlsList.get(0);
			
			if(Integer.parseInt(String.valueOf(lhm.get("id"))) == 101 && Integer.parseInt(String.valueOf(lhm.get("semisterId"))) == 76) {
			
			course1.put("id", 1001);
			course1.put("name", "Core Java");
			
			courseListMap.add(course1);
			
			course2.put("id", 1002);
			course2.put("name", "Adv. Java");
			
			courseListMap.add(course2);
			
			}else {
			
			course3.put("id", 1003);
			course3.put("name", "C-Language");
			
			courseListMap.add(course3);
			
			course4.put("id", 1004);
			course4.put("name", "C++");
			
			courseListMap.add(course4);
			
			}
			
			resp.put("courseList", courseListMap);
			resp.put("message", "Course List Delivered Successfully..!!");
			resp.put("errorCode", null);
			resp.put("status", true);
			
			}else {
				
				resp.put("courseList", new ArrayList<>());
				resp.put("message", "Course List Not Delivered Successfully..!!");
				resp.put("errorCode", ErrorConst.No_DATA_FOUND);
				resp.put("status", false);
				
			}
		
		}else {
			
			resp.put("courseList", new ArrayList<>());
			resp.put("message", "Course List Not Delivered Successfully..!!");
			resp.put("errorCode", ErrorConst.No_DATA_FOUND);
			resp.put("status", false);
			
		}
	
		
		return new ResponseEntity<>(resp, HttpStatus.OK);

	}
	
	@GetMapping(value = "/say-hello-get-for-entity")
	public ResponseEntity<Object> getSayHelloGetForEntity() {

		return new ResponseEntity<>("Hello Om Mahajan..!!", HttpStatus.OK);

	}
	
	@PostMapping(value = "/check-string-received-or-not")
	public ResponseEntity<Map<String, Object>> checkStringReceivedOrNot(@RequestHeader(required = false) String appKey,@RequestParam("apiKey") String apiKey, @RequestParam("str") String str) {

		try {
			Map<String, Object> responseMap = new HashMap<>();
		
			if(str != null) {
				responseMap.put("message", "String Received..");
				responseMap.put("status", true);
			}

			responseMap.put("message", "String Not Received..");
			responseMap.put("status", false);

			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}catch (Exception e){
			e.printStackTrace();
			throw e;
		}

	}
	
	@PostMapping(value = "/object-received")
	public ResponseEntity<?> objectReceived(@RequestHeader(required = false) String appKey,@RequestBody Map<String,Object> studentData) {

		try {
			Map<String, Object> responseMap = new HashMap<>();
		
			if(studentData != null && !studentData.isEmpty()) {
				responseMap.put("message", "String Received..");
				responseMap.put("status", true);
			}

			responseMap.put("message", "String Not Received..");
			responseMap.put("status", false);

			return new ResponseEntity<>(responseMap, HttpStatus.OK);
		}catch (Exception e){
			e.printStackTrace();
			throw e;
		}

	}

}
