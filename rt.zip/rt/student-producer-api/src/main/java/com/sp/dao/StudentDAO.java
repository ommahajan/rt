package com.sp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.sp.dto.StudentDTO;

@Repository
public class StudentDAO {
	
	@Autowired
//    @Qualifier(value = "kpDbJdbcTemplate")
    private JdbcTemplate jdbcTemplate;
	
	public Map<String, Object> getStudentListByDepartment(String department){
	
		SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate.getDataSource()).withProcedureName("getStudentsByDepartment").returningResultSet("stuentListByDepartmentFromProc" , new RowMapper<StudentDTO>() {
      		 
            @Override
            public StudentDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
            	StudentDTO studentDTO = new StudentDTO();
            	
            	studentDTO.setId(rs.getInt("id"));
            	studentDTO.setName(rs.getString("name"));
            	studentDTO.setDept(rs.getString("department"));
                 
                return studentDTO;
            }
        });
    	
    	SqlParameterSource inParam = new MapSqlParameterSource().addValue("departmentInParm", department);
		
		Map<String, Object> outParam = jdbcCall.execute(inParam);
		return outParam;
		
	}

}
