package com.sp.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sp.config.AppProperties;
import com.sp.constants.ErrorConst;
import com.sp.dto.CourseDetailsDTO;
import com.sp.dto.StudentDTO;
import com.sp.dto.StudentDetailsDTO;
import com.sp.exception.InvalidApiKeyException;
import com.sp.exception.InvalidAppKeyException;
import com.sp.service.SpService;

@RestController
@RequestMapping("/sca")
public class SpController {
	
    @Autowired
    SpService spService;
    
    @Autowired
	private AppProperties appProperties;
    
    @Autowired
	private RestTemplate restTemplate;
    
	private static final Logger logger = LoggerFactory.getLogger(SpController.class);
	
//    @GetMapping(value = "/get-student-list-by-department")
//	public ResponseEntity<Object> getStudentListByDepartment(HttpServletRequest request,
//			@RequestHeader("appKey") String appKey, @RequestParam("apiKey") String apiKey,
//			@RequestParam("dept") String dept) {
//		if (apiKey == null) {
//			throw new InvalidApiKeyException(ErrorConst.API_KEY_IS_REQUIRED,
//					"Api Key is required for accessing this Resource");
//		}
//
//		if (apiKey != null && apiKey.equals("XYZ")) {
//			if (appKey != null && !appKey.isEmpty() && "ABC".equals(appKey)) {
//				return new ResponseEntity<>(
//						spService.getStudentListByDepartment(dept),
//						HttpStatus.OK);
//
//			} else {
//				throw new InvalidAppKeyException(ErrorConst.INVALID_APP_KEY, "Invalid APP Key");
//			}
//		} else {
//			throw new InvalidApiKeyException(ErrorConst.INVALID_API_KEY, "Invalid API Key");
//		}
//
//	}
    
    @GetMapping(value = "/get-student-list-by-department")
   	public ResponseEntity<Object> getStudentListByDepartment(@RequestParam("dept") String dept) {

   				return new ResponseEntity<>(
   						spService.getStudentListByDepartment(dept),
   						HttpStatus.OK);

   	}
    
    @GetMapping(value = "/get-student-list-by-ids")
	public StudentDetailsDTO getStudentListByIds() {

		ResponseEntity<StudentDetailsDTO> response = null;
		List<Map<String, Object>> studIdList = new ArrayList<>();
		
		Map<String, Object> studId_1 = new HashMap<>();
		studId_1.put("studId", 2);
		
		Map<String, Object> studId_2 = new HashMap<>();
		studId_2.put("studId", 3);
		
		studIdList.add(studId_1);
		studIdList.add(studId_2);
		
		final String url = appProperties.getStudentProduceApiUrl() + "/get-student-list-by-ids";
		
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
 
			HttpEntity<List<Map<String, Object>>> entity = new HttpEntity<>(studIdList, headers);
			response = restTemplate.postForEntity(url, entity, StudentDetailsDTO.class);
			if(response!=null && response.getBody().getStatus().equals(true)) {
				return response.getBody();
			}
			
		} catch (Exception e) {
			logger.info("error reponse from api: - {}", e.getMessage());
			throw e;
		}
		return null;
	}
    
	@GetMapping(value = "/get-student-list-by-req-param-as-ids")
	public ResponseEntity<StudentDetailsDTO> getStudentListByReqParamIds() {

		final String url = appProperties.getStudentProduceApiUrl() + "/get-student-list-by-req-param-as-ids";

		String studIds = "2,3";

		StudentDetailsDTO forObject = restTemplate.getForObject(url.concat("?studIds=").concat(studIds),
				StudentDetailsDTO.class);
		logger.debug("Api response -> {}", forObject);
		return ResponseEntity.status(HttpStatus.OK).body(forObject);
	}
    
	@GetMapping("/say-hello")
	public ResponseEntity<?> sayHello() {
		
		final String url = appProperties.getStudentProduceApiUrl() + "/say-hello?str=Om Mahajan..!!";

//		RestTemplate rs = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_HTML);
		headers.setAccept(Collections.singletonList(MediaType.TEXT_HTML));
		HttpEntity<String> entity = new HttpEntity<>("body", headers);
		ResponseEntity<String> exchange = restTemplate.exchange(url, HttpMethod.GET,
				entity, String.class);
		String responseBody = exchange.getBody();
		return ResponseEntity.status(HttpStatus.OK).body(responseBody);

	}
	
	@GetMapping("/say-hello-with-api-key-and-response-as-map-object")
	public ResponseEntity<?> sayHelloWithApiKeyAndResponseAsMapObj() throws IOException{

		String status = "failed";
		final String url = appProperties.getStudentProduceApiUrl() + "/say-hello-with-api-key-and-response-as-map-object";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("apikey", appProperties.getStudentProduceApiKey());
		String strObject = "Om Mahajan..!!";
		HttpEntity<String> request = new HttpEntity<String>(strObject.toString(), headers);
		ResponseEntity<String> _sR = restTemplate.exchange(url, HttpMethod.POST, request,
				String.class);
		ObjectMapper _map = new ObjectMapper();
		@SuppressWarnings("unchecked")
		Map<String, Object> _m = _map.readValue(_sR.getBody(), Map.class);
		System.out.println("reply from Consumer : " + _m);
		if (_m.get("status").equals("success"))
			status = "success";
		return ResponseEntity.status(HttpStatus.OK).body(status);
	}
	
	@GetMapping("/say-hello-with-api-key-and-response-as-string-object")
	public ResponseEntity<?> sayHelloWithApiKeyAndResponseAsStringObj() throws IOException{

		String status = "failed";
		final String url = appProperties.getStudentProduceApiUrl() + "/say-hello-with-api-key-and-response-as-string-object";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("apikey", appProperties.getStudentProduceAppKey());
		String strObject = "Om Mahajan..!!";
		HttpEntity<String> request = new HttpEntity<String>(strObject.toString(), headers);
		ResponseEntity<String> _sR = restTemplate.exchange(url, HttpMethod.POST, request,
				String.class);
		String _m = _sR.getBody();
		System.out.println("reply from Consumer : " + _m);
		if (_m.equals("success"))
			status = "success";
		return ResponseEntity.status(HttpStatus.OK).body(status);
	}
	
	@GetMapping("/get-course-list-by-student-details")
	public ResponseEntity<?> getCourseListByStudentDetailsMediator() throws IOException{
		
		Map<String, Object> studDetailsMap = new HashMap<>();
		studDetailsMap.put("id", 101);
		studDetailsMap.put("semisterId", 76);
	
		return ResponseEntity.status(HttpStatus.OK).body(this.getCourseListByStudentDetails(studDetailsMap));
	}
	
	public CourseDetailsDTO getCourseListByStudentDetails(Map<String, Object> studDetailsMap) {

		final String url = appProperties.getStudentProduceApiUrl() + "/get-course-list-by-student-details";
		

		ResponseEntity<CourseDetailsDTO> response = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			HttpEntity<Object> requestEntity = new HttpEntity<>(Arrays.asList(studDetailsMap), headers);
			
			System.out.println("******" + Arrays.asList(studDetailsMap) + "******");
			
			if (studDetailsMap != null && !studDetailsMap.isEmpty()) {
				response = restTemplate.postForEntity(url, requestEntity, CourseDetailsDTO.class);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.getBody();
	}
	
	@GetMapping("/say-hello-get-for-entity")
	public ResponseEntity<String> getSayHelloGetForEntity(Integer count) {
        ResponseEntity<String> responseEntity = null;
        try {
        	
            URI uri =new URI(appProperties.getStudentProduceApiUrl() + "/say-hello-get-for-entity");
           
            responseEntity = restTemplate.getForEntity(uri, String.class);
            
        } catch (URISyntaxException e) {
            e.printStackTrace();
            logger.info("exception in API call getSayHelloGetForEntity");
        }
        return responseEntity;
    }
	
	@GetMapping(value = "/check-string-received-or-not")
	public ResponseEntity<Map<String, Object>> checkStringReceivedOrNot() {
		return this.checkStringReceivedOrNotCall();
	}
	
	public ResponseEntity<Map<String, Object>> checkStringReceivedOrNotCall() {
		Map<String, Object> respMap = new HashMap<>();
		HttpEntity<?> requestEntity = null;
		try {
			String str = "Om Mahajan..!!";
			String url = appProperties.getStudentProduceApiUrl() + "/check-string-received-or-not?apiKey=" + appProperties.getStudentProduceApiKey()
					+ "&str=" + str;
			HttpHeaders headers = new HttpHeaders();
			headers.add("appKey", appProperties.getStudentProduceAppKey());

			requestEntity = new HttpEntity<>(headers);
			logger.info("request : ", requestEntity);

			logger.info("url : ", url.toString());
			Object resp = restTemplate.postForEntity(url.toString(), requestEntity, Object.class);
			logger.info("response : ", resp);
			
			respMap.put("message", "String Received..");
			respMap.put("status", true);
			
			return new ResponseEntity<Map<String,Object>>(respMap, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Server Error : ", e);
			return null;
		}
		 
	 }
	
		@GetMapping(value = "/object-received")
		public ResponseEntity<Map<String, Object>> objectReceived(Integer type, String token, Object dataObj)
				throws IOException {
			try {

				Map<String, Object> responseMap = new HashMap<>();
				HttpClient client = HttpClientBuilder.create().build();
				HttpPost post = new HttpPost(appProperties.getStudentProduceApiUrl() + "/object-received");
				post.setHeader("Content-type", "application/json");
				post.setHeader("Authorization", "key=" + appProperties.getStudentProduceOtherKey());

				JSONObject requestObject = new JSONObject();

				requestObject.put("id", 101);
				requestObject.put("name", "Om");

				logger.info("requestObject :  " + requestObject);

				post.setEntity(new StringEntity(requestObject.toString(), "UTF-8"));
				HttpResponse response = client.execute(post);
				logger.info("**response** : ", response);

				if (response != null) {
					responseMap.put("message", "Object sent successfully..");
					responseMap.put("status", true);
				} else {
					responseMap.put("message", "Object Not sent successfully..");
					responseMap.put("status", true);
				}

				return new ResponseEntity<>(responseMap, HttpStatus.OK);
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}

		}


}
