package com.sp.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class StudentDetailsDTO  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("studentList")
	private List<StudentDTO> studentList;
	@JsonProperty("message")
	private String message;
	@JsonProperty("errorCode")
	private String errorCode;
	@JsonProperty("status")
	private Boolean status;

}
