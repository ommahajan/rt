/**
 * 
 */
package com.sp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class AppProperties {

	
	@Value("${student.produce.api.url}")
	private String studentProduceApiUrl;
	
	@Value("${student.produce.api.key}")
	private String studentProduceApiKey;
	
	@Value("${student.produce.app.key}")
	private String studentProduceAppKey;
	
	@Value("${student.produce.other.key}")
	private String studentProduceOtherKey;



}
